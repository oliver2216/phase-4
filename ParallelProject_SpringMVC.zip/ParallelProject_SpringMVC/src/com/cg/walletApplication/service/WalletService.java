package com.cg.walletApplication.service;
import java.math.BigDecimal;
import com.cg.walletApplication.beans.Customer;
import com.cg.walletApplication.exception.InsufficientBalanceException;
import com.cg.walletApplication.exception.MobileNumberDoesNotExistException;

public interface WalletService {
public Customer createAccount(Customer customer);
public Customer showBalance (String mobileno) throws MobileNumberDoesNotExistException;
public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount) throws MobileNumberDoesNotExistException, InsufficientBalanceException;
public Customer depositAmount (String mobileNo,BigDecimal amount )throws MobileNumberDoesNotExistException;
public Customer withdrawAmount(String mobileNo, BigDecimal amount)throws MobileNumberDoesNotExistException, InsufficientBalanceException;
}
