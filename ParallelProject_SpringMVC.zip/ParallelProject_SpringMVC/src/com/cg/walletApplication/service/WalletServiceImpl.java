package com.cg.walletApplication.service;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.cg.walletApplication.beans.Customer;
import com.cg.walletApplication.beans.Wallet;
import com.cg.walletApplication.exception.InsufficientBalanceException;
import com.cg.walletApplication.exception.MobileNumberDoesNotExistException;
import com.cg.walletApplication.repo.WalletRepo;

@Service("ser")
@Component(value="ser")
public class WalletServiceImpl implements WalletService{
	
	@Autowired
	private WalletRepo repo;
	public WalletServiceImpl() {
		super();
	}

	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}



	public Customer createAccount(Customer customer) {
		
		return repo.save(customer);
		}
	
	 
	public Customer showBalance(String mobileNo)  {
		Customer customer=repo.findOne(mobileNo);
		
			return customer;	
	}
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws MobileNumberDoesNotExistException, InsufficientBalanceException {

		Customer cust1=repo.findOne(sourceMobileNo);
		Customer cust2=repo.findOne(targetMobileNo);
		if(cust1!=null)
		{
			if(cust2!=null)
			{
				BigDecimal bal1 = cust1.getWallet().getBalance();
				BigDecimal bal2 = cust2.getWallet().getBalance();
				if(bal1.compareTo(amount)>=0)
				{
					bal1 = bal1.subtract(amount);
				cust1.setWallet(new Wallet(bal1));
				repo.save(cust1);
					bal2=bal2.add(amount);
				cust2.setWallet(new Wallet(bal2));
				repo.save(cust2);				
				
				}
				else
				{
					throw new InsufficientBalanceException();					
				}
			}
			else
			{
				throw new MobileNumberDoesNotExistException();
			}
		}else
		{
			throw new MobileNumberDoesNotExistException();
		}
		
		
		return cust1;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws MobileNumberDoesNotExistException{

		Customer cust=repo.findOne(mobileNo);
			BigDecimal bal = cust.getWallet().getBalance().add(amount);
			cust.setWallet(new Wallet(bal));
			repo.save(cust);
		return cust;	
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws MobileNumberDoesNotExistException, InsufficientBalanceException {
		if(amount==null)
			throw new MobileNumberDoesNotExistException();
		
		if(mobileNo==null)
			throw new MobileNumberDoesNotExistException();

		Customer cust=repo.findOne(mobileNo);
		if(cust.getMobileNo()==null)
			throw new MobileNumberDoesNotExistException();
		BigDecimal bal = cust.getWallet().getBalance();
	if(bal.compareTo(amount)>=0)
	{
		bal = bal.subtract(amount);
	cust.setWallet(new Wallet(bal));
	repo.save(cust);
	}
	else
	{
		throw new InsufficientBalanceException();		
	}
	return cust;
}
}