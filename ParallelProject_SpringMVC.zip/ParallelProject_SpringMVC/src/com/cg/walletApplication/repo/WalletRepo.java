package com.cg.walletApplication.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.walletApplication.beans.Customer;

public interface WalletRepo extends JpaRepository<Customer, String> {
		
}
