package com.cg.walletApplication.exception;

public class MobileNumberDoesNotExistException extends Exception{

	@Override
	public String getMessage() {
		
		return "Mobile number does not exist!!";
	}
	
}
